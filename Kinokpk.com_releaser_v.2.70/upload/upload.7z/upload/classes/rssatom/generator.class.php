<?php
interface Generator {
	public function generate(Channel $channel);
	public function generatorName();
}
?>
