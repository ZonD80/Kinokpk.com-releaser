<?
$tracker_lang['wrong_id'] = 'Direct access to this script not allowed, or wrong ID';
$tracker_lang['anonymous_release'] = 'Anonymous release';
$tracker_lang['release_anonymous'] = 'The release is now anonymous';
$tracker_lang['close_window'] = 'Close window';
$tracker_lang['make_anonymous'] = 'Make anonymous releases';
$tracker_lang['owner_release'] = 'Owner release ';
$tracker_lang['restored'] = 'restored';
?>