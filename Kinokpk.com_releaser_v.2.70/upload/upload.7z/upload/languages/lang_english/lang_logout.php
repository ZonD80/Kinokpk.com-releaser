<?
$tracker_lang['succ_logout'] = 'Successful logout';
$tracker_lang['you_succ_logout'] = 'You have successfully logout!';
$tracker_lang['continue'] = 'Continue';
?>