<?php
// language for cronadmin

$tracker_lang['title'] = 'Cron functions setup';
$tracker_lang['rt_state_1'] = '<font color="red">Stop request was send, but script is still running. Wait please</font>';
$tracker_lang['rt_state_2'] = '<font color="green">Stopped</font>';
$tracker_lang['rt_state_3'] = '<font color="green">Working</font>';
$tracker_lang['rt_state_4'] = '<font color="red">Start request was send, script is starting now';

$tracker_lang['cron_state_reseted'] = 'Cron-function settings successfully reseted';
$tracker_lang['cron_settings_saved'] = 'Cron-function setting successfully saved';