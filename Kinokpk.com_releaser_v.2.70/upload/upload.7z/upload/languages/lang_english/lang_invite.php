<?php
$tracker_lang['invite_notice'] = 'To invite anybody you can <a href="mybonus.php">exchange your bonus</a>';
?>