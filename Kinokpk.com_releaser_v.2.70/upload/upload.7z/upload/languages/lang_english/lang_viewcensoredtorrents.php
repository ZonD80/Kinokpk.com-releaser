<?
$tracker_lang['error'] = 'Error';
$tracker_lang['success'] = 'Successful';
$tracker_lang['ban_releases'] = 'Ban releases';
$tracker_lang['no_fields_blank'] = 'Do not leave any fields blank.';
$tracker_lang['ban_uninstalled'] = 'The ban has been successfully uninstalled.<br /> <a href="viewcensoredtorrents.php">list of bans</a>';
$tracker_lang['not_permission_prohibitions'] = 'You do not have permission to remove the prohibitions.';
$tracker_lang['banned_releases'] = 'Banned releases [descending]';
$tracker_lang['title'] = 'Title';
$tracker_lang['reason_ban'] = 'The reason for the ban';
$tracker_lang['more'] = 'More';
$tracker_lang['add_ban'] = 'Add a ban';
?>