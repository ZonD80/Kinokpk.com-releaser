<?
$tracker_lang['error'] = 'Error';
$tracker_lang['access_denied'] = 'Access denied.';
$tracker_lang['not_filled_fields'] = 'You have not filled in all fields!';
$tracker_lang['not_entered_number'] = 'You have entered no number in the box below:';
?>