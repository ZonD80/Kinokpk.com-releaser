<?
$tracker_lang['error'] = 'Error';
$tracker_lang['access_denied'] = 'Access denied.';
$tracker_lang['enter_topic'] = 'Please enter the topic!';
$tracker_lang['enter_message'] = 'Enter your message!';
$tracker_lang['bulk_email'] = 'Bulk E-mail';
$tracker_lang['success'] = 'Successful';
$tracker_lang['mailer_seccessful'] = 'Mailer successful. Sent';
$tracker_lang['messages'] = 'messages';
?>