<?
$tracker_lang['form_contact'] = 'Form of contact';
$tracker_lang['form_contact_for_admin'] = 'The form for communication with the Administration';
$tracker_lang['your_name'] = 'Your name:';
$tracker_lang['your_email'] = 'Your Email:';
$tracker_lang['subject'] = 'Subject:';
$tracker_lang['problem_activation'] = 'Problems with activation';
$tracker_lang['bugs_site'] = 'Bugs site';
$tracker_lang['quest_realeases'] = 'Questions about the releases';
$tracker_lang['suggestions'] = 'Suggestions';
$tracker_lang['become_uploader'] = 'I would like to become a uploader!';
$tracker_lang['acc_disabled'] = 'My Account is disabled, what to do?';
$tracker_lang['other'] = 'Other';
$tracker_lang['your_message'] = 'Your message';
$tracker_lang['you_people'] = 'You people?';
$tracker_lang['clean'] = 'Clean';
$tracker_lang['submit'] = 'Submit';
?>