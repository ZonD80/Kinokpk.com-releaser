<?
$tracker_lang['not_confirmed_users'] = 'Not confirmed users';
$tracker_lang['username'] = 'Username';
$tracker_lang['email'] = 'eMail';
$tracker_lang['registered'] = 'Registered';
$tracker_lang['status'] = 'Status';
$tracker_lang['confirm'] = 'Confirm';
$tracker_lang['not_confirmed'] = 'Not confirmed';
$tracker_lang['confirmed'] = 'Confirmed';
$tracker_lang['no_conf_usr'] = 'There is no confirmed users ...';
?>