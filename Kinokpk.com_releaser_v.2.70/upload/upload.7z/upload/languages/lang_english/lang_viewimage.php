<?
$tracker_lang['view_images'] = 'View images';
$tracker_lang['back'] = 'Back';
?>