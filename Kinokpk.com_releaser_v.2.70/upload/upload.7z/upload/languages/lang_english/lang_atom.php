<?
$tracker_lang['news'] = 'news';
$tracker_lang['no_releases'] = 'No releases';
$tracker_lang['genre'] = 'Genre:';
$tracker_lang['anonymous'] = 'Anonymous';
$tracker_lang['posted'] = 'Posted:';
$tracker_lang['size'] = 'Size:';
$tracker_lang['added'] = 'Added:';
$tracker_lang['comments'] = 'Comments:';
$tracker_lang['preview'] = 'Preview';
$tracker_lang['full_lst_rel'] = 'Full list of releases';
?>