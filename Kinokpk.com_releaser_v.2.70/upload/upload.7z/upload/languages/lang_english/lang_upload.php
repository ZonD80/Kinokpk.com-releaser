<?php

$tracker_lang['multitracker_torrent'] = 'Multitracker torrent';
$tracker_lang['multitracker_torrent_notice'] = 'Check this box, if u are uploading torrent file from other tracker';
$tracker_lang['approve'] = 'Approve release<br /><small>If selected, release will be shown around the releaser, not in test-releaser only</small>';
$tracker_lang['check'] = 'Checking';
$tracker_lang['main_category'] ='Main category';
$tracker_lang['subcats'] ='Extra categories';
?>