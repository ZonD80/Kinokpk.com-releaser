<?
$tracker_lang['error'] = 'Error';
$tracker_lang['access_denied'] = 'Access denied.';
$tracker_lang['missing_data'] = 'Missing form data.';
$tracker_lang['un_upd_acc'] = 'Unable to update account.';
$tracker_lang['upd_users_inv_amn'] = 'Update Users Invite Amounts';
$tracker_lang['user_name'] = 'User name';
$tracker_lang['invites'] = 'Invites';
?>