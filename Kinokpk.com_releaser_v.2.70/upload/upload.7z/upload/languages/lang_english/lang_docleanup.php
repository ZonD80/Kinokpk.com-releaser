<?
$tracker_lang['forced_cleaning'] = 'Forced Cleaning';
$tracker_lang['done'] = 'Done';
$tracker_lang['cleanup_completed'] = 'Cleanup completed successfully. Used to clean %s request(s).';
?>