<?
$tracker_lang['error'] = 'Error';
$tracker_lang['upload_avatar'] = 'Upload avatar';
$tracker_lang['select_avatar'] = 'Select your avatar';
$tracker_lang['upload'] = 'Upload';
$tracker_lang['hint'] = 'Hint: Avatar must be no more %d kilobytes,<br /> and no more %d x %d pixels';
$tracker_lang['not_pic'] = 'This is not a picture, access is denied';
$tracker_lang['attention'] = 'Attention! Allowed image formats: JPG, PNG, GIF.';
$tracker_lang['invalid_filename'] = 'Invalid file name (not the picture or the wrong format).';
$tracker_lang['size_you_avatar'] = '<br />Size of your avatar %sx%s. Required size not more than %sx%s pixels';
$tracker_lang['size_exceeds'] = '<br />The size of your avatars exceeds %s kb!';
$tracker_lang['succes_upload'] = '<b>Your avatar has been successfully uploaded to the server!</b><hr /> Filename: <b>';
$tracker_lang['file_size'] = '</b><br />File Size: <b> %s kb. </b><hr /><center>Avatar automatically added to the user profile</center>';
?>