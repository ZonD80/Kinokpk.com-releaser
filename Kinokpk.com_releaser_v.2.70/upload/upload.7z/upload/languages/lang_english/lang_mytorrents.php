<?
$tracker_lang['error'] = 'Error';
$tracker_lang['my_releases'] = 'My Releases';
$tracker_lang['not_releases'] = 'You may not download releases on this tracker.';
?>