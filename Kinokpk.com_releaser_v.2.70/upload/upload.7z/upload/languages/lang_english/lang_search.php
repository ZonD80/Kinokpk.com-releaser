<?
$tracker_lang['search'] = 'Search';
$tracker_lang['in'] = 'in ';
$tracker_lang['all_types'] = '(All Types)';
$tracker_lang['including_dead'] = 'including dead';
?>