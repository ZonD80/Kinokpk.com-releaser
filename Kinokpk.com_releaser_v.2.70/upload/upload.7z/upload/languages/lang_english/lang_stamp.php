<?
$tracker_lang['stamps'] = 'Stamps';
$tracker_lang['stamps_seals'] = 'Stamps and seals ';
$tracker_lang['close_window'] = 'Close window';
?>