<?
$tracker_lang['error'] = 'Error';
$tracker_lang['test_humanity'] = 'You are not tested for humanity, please try again.';
$tracker_lang['send_email_admin'] = 'Send e-mail administration';
$tracker_lang['check_address'] = 'Check whether the address entered Email!';
$tracker_lang['links_prohibited'] = 'Links in the message is prohibited!';
$tracker_lang['not_subject'] = 'You did not specify a subject for your message!';
$tracker_lang['not_name_sender'] = 'You have not specified the name of the sender!';
$tracker_lang['not_email'] = 'You did not specify the sender\'s Email!';
$tracker_lang['not_text_message'] = 'You have not filled out the box with the text message!';
$tracker_lang['code_incorrectly'] = 'Code from the image is entered incorrectly or not entered!';
$tracker_lang['relationship'] = ' - Relationship with the Administration';
$tracker_lang['message_from'] = '<b>Message from</b>:';
$tracker_lang['ip_sender'] = '<b>IP sender</b>:';
$tracker_lang['email_sender'] = '<b>E-Mail sender</b>:';
$tracker_lang['subject'] = '<b>Subject</b>:';
$tracker_lang['message'] = '<b>Message</b>:';
$tracker_lang['user_agent'] = '<b>User agent</b>:';
$tracker_lang['thanks'] = 'Thanks';
$tracker_lang['message_sent'] = 'Your message has been sent to the administration.';
$tracker_lang['home'] = 'Home '.$CACHEARRAY['defaultbaseurl'].'';
?>