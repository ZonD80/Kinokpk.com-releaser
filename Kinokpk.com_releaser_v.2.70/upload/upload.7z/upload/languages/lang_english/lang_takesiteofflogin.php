<?
$tracker_lang['error'] = 'Error';
$tracker_lang['back'] = 'Back';
$tracker_lang['not_spec'] = 'You have not specified a username and (or) password!';
$tracker_lang['you_not_logged'] = 'You are not logged in!';
$tracker_lang['not_act_account'] = 'You have not yet activated your account! Activate your account and try again.';
$tracker_lang['incorrect'] = 'Username or password incorrect!';
$tracker_lang['this_acc_disabled'] = 'This account has been disabled.';
$tracker_lang['this_acc_active'] = 'This user is active at the moment. Sign impossible!';
?>