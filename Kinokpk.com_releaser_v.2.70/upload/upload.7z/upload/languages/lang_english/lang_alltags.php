<?
$tracker_lang['cloud_tags'] = 'A large cloud of tags';
?>