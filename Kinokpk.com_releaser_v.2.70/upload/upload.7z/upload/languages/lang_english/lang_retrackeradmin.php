<?php

$tracker_lang['panel_name'] = 'Retrackers administration';
$tracker_lang['panel_notice'] = 'Whis page allows you to manage retrackers<br />
Warning, there are <b>RETRACKERS</b>, and they will be added to .torrent file only <b>when user downloading torrent!
You <b>cant</b> access any statistics of this trackers.<br />
<b><u>"Mask" field can contain one IP address or subnet mask in CIDR format</u></b><br />
Leave "Mask" blank if you want to add retracker to all users.';
$tracker_lang['add_retracker'] = 'Add retracker';
$tracker_lang['order'] = 'Order';
$tracker_lang['announce_url'] = 'Announce URL';
$tracker_lang['subnet_mask'] = 'Subnet mask';
$tracker_lang['edit_delete'] = 'Edit/Delete';
$tracker_lang['are_you_sure'] = 'Are you sure?';
$tracker_lang['save_order'] = 'Save order';
$tracker_lang['editing_retracker'] = 'Editing retracker';
?>