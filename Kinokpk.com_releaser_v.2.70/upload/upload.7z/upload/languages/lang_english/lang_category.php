<?php

// LANGUAGE FOR CATEGORY ADMIN

$tracker_lang['category_admin'] = 'Categories admincp';
$tracker_lang['add_new_category'] = 'Add new category';
$tracker_lang['category_success_delete'] = 'Category successful deleted';
$tracker_lang['category_success_edit'] = 'Category sucessful edited';
$tracker_lang['you_edit'] = 'You editing';
$tracker_lang['no_parent'] = 'No parent';
$tracker_lang['parent'] = 'Parent';
$tracker_lang['export_id'] = 'ID of IPB\'s forum<br /><small>Leave field blank for automatic export, if category name and forum name are the same</small>';
$tracker_lang['add_new_category'] = 'Category successful added';
$tracker_lang['add_new_category'] = 'Adding new category';
$tracker_lang['cur_tree'] = 'Current category tree';
$tracker_lang['forum_id'] = 'IPB\'s forum ID';
$tracker_lang['confirmation_delete'] = 'Are you sure?';
$tracker_lang['disable_export'] = 'Disable export to IPB for this category';
$tracker_lang['disable_export_short'] = 'Export disabled';
$tracker_lang['sort'] = 'Order';