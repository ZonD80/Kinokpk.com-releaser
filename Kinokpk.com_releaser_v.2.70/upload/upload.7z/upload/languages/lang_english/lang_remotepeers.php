<?
$tracker_lang['error'] = 'Error';
$tracker_lang['invalid_id'] = 'Invalid ID.';
$tracker_lang['invalid_result'] = ': invalid query result';
$tracker_lang['del_peers'] = 'Deleted peers';
$tracker_lang['invaled_passed'] = 'invalid arguments passed';
$tracker_lang['distr_our_tracker'] = 'This torrent at the moment is distributed only on our tracker.';
$tracker_lang['unable_peers'] = 'Unable to obtain data on the peers of the remote tracker';
$tracker_lang['leechers_l'] = 'leechers';
$tracker_lang['peers_l'] = 'peers';
?>