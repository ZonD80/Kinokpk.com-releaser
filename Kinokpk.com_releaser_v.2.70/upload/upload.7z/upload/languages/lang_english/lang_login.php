<?
$tracker_lang['error'] = 'Error';
$tracker_lang['logged'] = 'You are already logged on ';
$tracker_lang['logged_on'] = 'Unfortunately the page you are trying to view is only available <b> logged on </b>. <br /> After successful login you will be redirected to the requested page.';
?>