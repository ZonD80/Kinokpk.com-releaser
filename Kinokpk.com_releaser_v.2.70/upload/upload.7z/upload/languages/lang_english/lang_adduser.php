<?
$tracker_lang['error'] = 'Error';
$tracker_lang['access_denied'] = 'Access denied.';
$tracker_lang['missing_form_data'] = 'Please fill in all fields.';
$tracker_lang['password_mismatch'] = 'Passwords do not match.';
$tracker_lang['unable_to_create_account'] = 'Unable to create an account. Perhaps the user name already exists. ';
$tracker_lang['add_user'] = 'Add user';
$tracker_lang['username'] = 'Username';
$tracker_lang['password'] = 'Password';
$tracker_lang['repeat_password'] = 'Confirm password';
?>