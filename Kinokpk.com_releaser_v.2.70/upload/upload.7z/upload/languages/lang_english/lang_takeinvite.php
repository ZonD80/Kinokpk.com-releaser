<?
$tracker_lang['dont_invite'] = 'You do not have invitions!';
?>