<?
$tracker_lang['error'] = 'Error';
$tracker_lang['no_selection'] = 'No selection';
$tracker_lang['not_try_remove'] = 'You are not trying to remove a bookmark!';
?>