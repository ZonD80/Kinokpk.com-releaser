<?
$tracker_lang['error'] = 'Error';
$tracker_lang['access_denied'] = 'Access denied.';
$tracker_lang['bulk_email'] = 'Bulk E-mail';
$tracker_lang['subject'] = 'Subject:';
$tracker_lang['submit'] = 'Submit';
?>