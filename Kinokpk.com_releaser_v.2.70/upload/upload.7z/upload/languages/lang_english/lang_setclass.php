<?
$tracker_lang['change_class'] = 'Change of class';
$tracker_lang['class'] = 'Class';
$tracker_lang['class_override_denied'] = 'Class overriding denied, your class is too low';
?>