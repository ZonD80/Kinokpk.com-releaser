<?php
$tracker_lang['country_admin'] = 'Management Country and Flags';
$tracker_lang['country_and_flags'] = 'Countries and Flags';
$tracker_lang['confirmation_delete'] = 'Confirmation Delete';
$tracker_lang['country_success_delete'] = 'Country Success Delete';
$tracker_lang['country_success_edit'] = 'Country Success Edit';
$tracker_lang['back'] = 'Back';
$tracker_lang['country'] = 'Country';
$tracker_lang['flag'] = 'Flag';
$tracker_lang['name'] = 'Name';
$tracker_lang['you_edit'] = 'You edit';
$tracker_lang['add_new_country'] = 'Add a New Country';
$tracker_lang['create_country'] = 'Create Country';
$tracker_lang['success'] = 'Success!';
$tracker_lang['edit'] = 'Edit';
$tracker_lang['delete'] = 'Delete';

?>