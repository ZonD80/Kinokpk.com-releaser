<?
$tracker_lang['error'] = 'Error';
$tracker_lang['invalid_id'] = 'Invalid ID.';
$tracker_lang['how_did_get_here'] = 'How did you get here? <a href=\"javascript:history.go(-1)\">Back</a>';
$tracker_lang['have_been_last_release'] = 'You have been in the last release';
$tracker_lang['this_category'] = 'this category';
$tracker_lang['back'] = '. <a href=\"javascript:history.go(-1)\">Back</a>';
$tracker_lang['have_first_release'] = 'You have to first release';
?>