<?
$tracker_lang['error'] = 'Error';
$tracker_lang['success'] = 'Successful';
$tracker_lang['no_access'] = 'No Access.';
$tracker_lang['fill_form'] = 'Please fill out the form correctly.';
$tracker_lang['invalid_username'] = 'Invalid username. Please check your input.';
$tracker_lang['cant_dell_acc'] = 'You can not delete your account.';
$tracker_lang['account'] = 'Account';
$tracker_lang['removed'] = 'removed.';
$tracker_lang['delete_account'] = 'Delete Account';
$tracker_lang['username'] = 'Username';
$tracker_lang['remove'] = 'Remove';
?>