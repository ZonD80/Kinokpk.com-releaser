<?
$tracker_lang['error'] = 'Error';
$tracker_lang['access_denied'] = 'Access denied.';
$tracker_lang['select_user'] = 'You should select the user for editing.';
$tracker_lang['you_warning_removed'] = 'Your warning removed ';
$tracker_lang['warning_removed'] = ' - Warning removed ';
?>