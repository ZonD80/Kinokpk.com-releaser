<?
$tracker_lang['change_user_pass'] = 'Change user password';
$tracker_lang['not_sysop'] = 'Access denied. You\'re not SYSOP';
$tracker_lang['change_usr_succ'] = 'Change the user\'s successful';
$tracker_lang['username'] = 'Username:';
$tracker_lang['new_password'] = '<br /> New Password:';
$tracker_lang['new_email'] = '<br /> New Email:';
$tracker_lang['change_password'] = 'Change Password';
$tracker_lang['change'] = 'Change';
$tracker_lang['your_class_is_lower'] = 'Your class is too low, you cant change password of this user';
?>