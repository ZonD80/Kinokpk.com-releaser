<?
$tracker_lang['test_port'] = 'Test port';
$tracker_lang['new_port_test'] = 'New Port test';
$tracker_lang['is_on_the_port'] = 'is on the Port:';
$tracker_lang['not_good'] = 'not good!';
$tracker_lang['good'] = 'good!';
$tracker_lang['port_number'] = 'Port number:';
?>