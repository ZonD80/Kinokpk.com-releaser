<?
$tracker_lang['empty_motive'] = 'You din\' enter any report';
$tracker_lang['complaint_lodged'] = 'Complaint lodged';
$tracker_lang['user'] = 'User';
$tracker_lang['complaint_torrent'] = 'complaint was filed in the torrent';
$tracker_lang['reason'] = 'Reason: ';
?>