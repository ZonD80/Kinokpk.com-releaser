<?
$tracker_lang['error'] = 'Error';
$tracker_lang['break_attempt'] = 'Possible breakin attempt';
$tracker_lang['enter_message'] = 'Please enter a message!';
$tracker_lang['enter_subject'] = 'Please enter the subject!';
$tracker_lang['select_classes'] = 'Select 1 or more classes to send the message.';
$tracker_lang['mass_mailing'] = 'Mass mailing from the user';
$tracker_lang['success'] = 'Successful';
$tracker_lang['send'] = 'Send';
$tracker_lang['messages'] = 'messages.';
?>