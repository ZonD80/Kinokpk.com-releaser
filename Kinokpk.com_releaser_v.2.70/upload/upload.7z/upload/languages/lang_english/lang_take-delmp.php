<?
$tracker_lang['error'] = 'Error';
$tracker_lang['not_chosen_message'] = 'You have not chosen to delete the message!';
$tracker_lang['back'] = 'Back';
?>