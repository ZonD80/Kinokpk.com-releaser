<?
$tracker_lang['error'] = 'Error';
$tracker_lang['invalid_id'] = 'Invalid ID.';
$tracker_lang['no_user_id'] = 'No user with that ID';
$tracker_lang['error_calculating'] = 'Error of calculating the confirmation code';
$tracker_lang['code_incorrect'] = 'Confirmation code is incorrect';
$tracker_lang['error_change_address'] = 'Error change of address ';
?>