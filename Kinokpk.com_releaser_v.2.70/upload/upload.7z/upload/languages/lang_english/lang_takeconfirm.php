<?
$tracker_lang['invite_confirmed'] = 'Your inviter just approve your invite, your upload got %s megabytes up';
$tracker_lang['invite_confirmed_title'] = 'Your invite confirmed';
?>