<?
$tracker_lang['error'] = 'Error';
$tracker_lang['permission_denied'] = 'Permission denied';
$tracker_lang['result'] = 'Result';
$tracker_lang['ip_address'] = 'IP address';
$tracker_lang['not_banned'] = 'not banned.';
$tracker_lang['banned'] = 'banned.';
$tracker_lang['check_ip'] = 'Check the IP address';
?>