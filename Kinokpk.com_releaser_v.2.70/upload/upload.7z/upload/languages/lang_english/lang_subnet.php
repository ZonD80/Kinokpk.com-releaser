<?
$tracker_lang['error'] = 'Error';
$tracker_lang['invalid_subnet'] = 'Invalid subnet mask.';
$tracker_lang['network_neighbot'] = 'Network Neighborhood';
$tracker_lang['speed_above'] = 'These users of your network neighbors, which means that you get from them the speed above.';
$tracker_lang['username'] = 'Username';
$tracker_lang['up_size'] = 'Up size';
$tracker_lang['down_size'] = 'Down size';
$tracker_lang['ratio'] = 'Ratio';
$tracker_lang['registered'] = 'Registered';
$tracker_lang['last_access'] = 'Last access';
$tracker_lang['class'] = 'Class';
$tracker_lang['information'] = 'Information';
$tracker_lang['not_found_neighbot'] = 'Network Neighborhood not found.';
?>