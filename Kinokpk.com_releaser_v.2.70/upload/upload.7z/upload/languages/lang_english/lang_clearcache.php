<?
$tracker_lang['error'] = 'Error';
$tracker_lang['access_denied'] = 'Access denied.';
$tracker_lang['cleaning_cache'] = 'Cleaning cache';
$tracker_lang['select_cache'] = 'Select to clear the cache';
$tracker_lang['name_cache'] = 'Name cache';
$tracker_lang['select_all'] = 'Select all';
$tracker_lang['mark_all'] = 'Mark all';
$tracker_lang['clean'] = 'Clean!';
$tracker_lang['dont_set_cache'] = 'Do not set the cache to clear';
$tracker_lang['cache'] = 'Cache';
$tracker_lang['succ_purif'] = 'was successfully purified';
$tracker_lang['cache_cleared'] = 'Cache cleared';
?>