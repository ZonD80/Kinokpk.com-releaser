<?
$tracker_lang['error'] = 'Error';
$tracker_lang['torrent'] = 'Torrent';
$tracker_lang['bookmarked'] = ' was added to your bookmarks.';
$tracker_lang['success'] = 'Successful';
$tracker_lang['torrent_not_selected'] = 'Torrent not selected!';
$tracker_lang['already_bookmarked'] = ' already in bookmarks.';
?>