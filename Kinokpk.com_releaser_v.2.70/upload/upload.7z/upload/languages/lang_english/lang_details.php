<?php

$tracker_lang['view'] = 'View';
$tracker_lang['screens'] = 'Screenshots';
$tracker_lang['not_yet_checked'] = '<font color="red">This release <b>NOT</b> yet checked by moderator';
$tracker_lang['checked_by'] = '<font color="green">This release <b>was checked</b> by ';
$tracker_lang['check'] = 'Check';
$tracker_lang['uncheck'] = 'Uncheck';
$tracker_lang['include_remote'] = ', exclude %s %s on remote trackers';

?>