<?
$tracker_lang['error'] = 'Error';
$tracker_lang['invalid_id'] = 'Invalid ID.';
?>