<?
$tracker_lang['logs'] = 'Logs';
$tracker_lang['tracker'] = 'Tracker';
$tracker_lang['bans'] = 'Bans';
$tracker_lang['release'] = 'Release';
$tracker_lang['exchange'] = 'Exchange';
$tracker_lang['torrent'] = 'Torrents';
$tracker_lang['errors'] = 'Errors';
$tracker_lang['error'] = 'Error';
$tracker_lang['access_closed'] = 'Access to this section is closed.';
$tracker_lang['log_file_empty'] = 'The log file is empty';
$tracker_lang['date'] = 'Date';
$tracker_lang['time'] = 'Time';
$tracker_lang['event'] = 'Event';
?>