tinyMCE.addI18n('en.kinopoisk_dlg',{
title:"Kinopoisk parser"
});