tinyMCE.addI18n('ru.kinopoisk',{
kinopoisk_desc: "Заполнить шаблон, используя данные kinopoisk.ru"
});