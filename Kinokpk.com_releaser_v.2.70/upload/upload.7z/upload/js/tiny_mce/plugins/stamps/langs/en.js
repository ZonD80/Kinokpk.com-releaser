tinyMCE.addI18n('en.stamps',{
stamp_desc:"Stamps"
});