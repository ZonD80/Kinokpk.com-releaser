<?php
header("Location: rss.php");
?>