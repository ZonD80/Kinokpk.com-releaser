tinyMCE.addI18n('en.reltemplates',{
reltemplate_desc:"Reltemplates"
});