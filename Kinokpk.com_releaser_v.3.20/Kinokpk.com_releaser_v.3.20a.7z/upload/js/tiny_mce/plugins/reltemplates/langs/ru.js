tinyMCE.addI18n('ru.reltemplates',{
reltemplates_desc: "\u0428\u0430\u0431\u043b\u043e\u043d\u044b \u0440\u0435\u043b\u0438\u0437\u043e\u0432"
});