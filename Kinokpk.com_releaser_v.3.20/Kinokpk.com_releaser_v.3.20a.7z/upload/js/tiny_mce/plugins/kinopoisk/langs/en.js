tinyMCE.addI18n('en.kinopoisk',{
kinopoisk_desc:"Fill the form using information from kinopoisk.ru"
});