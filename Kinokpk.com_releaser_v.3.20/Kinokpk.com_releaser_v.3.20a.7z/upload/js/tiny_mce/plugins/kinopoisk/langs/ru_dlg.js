tinyMCE.addI18n('ru.kinopoisk_dlg',{
title:"\u0417\u0430\u043F\u043E\u043B\u043D\u0438 \u0428\u0430\u0431\u043B\u043E\u043D"
});