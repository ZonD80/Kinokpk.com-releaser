<?php
/**
 * Delete user accounts via admincp
 * @license GNU GPLv3 http://opensource.org/licenses/gpl-3.0.html
 * @package Kinokpk.com releaser
 * @author ZonD80 <admin@kinokpk.com>
 * @copyright (C) 2008-now, ZonD80, Germany, TorrentsBook.com
 * @link http://dev.kinokpk.com
 */


require "include/bittorrent.php";
dbconn();
$REL_LANG->load('delacctadmin');
loggedinorreturn();

if (get_user_class() < UC_ADMINISTRATOR)
stderr($REL_LANG->say_by_key('error'), $REL_LANG->say_by_key('no_access'));

httpauth();

if ($HTTP_SERVER_VARS["REQUEST_METHOD"] == "POST")
{
	$username = htmlspecialchars(trim((string)$_POST["username"]));

	if (!$username)
	stderr($REL_LANG->say_by_key('error'), $REL_LANG->say_by_key('fill_form'));

	$res = sql_query("SELECT * FROM users WHERE username=" . sqlesc($username)) or sqlerr(__FILE__, __LINE__);
	if (mysql_num_rows($res) != 1)
	stderr($REL_LANG->say_by_key('error'), $REL_LANG->say_by_key('invalid_username'));
	$arr = mysql_fetch_assoc($res);

	$id = $arr['id'];
	$avatar = $arr['avatar'];
	$class = $arr['class'];
	if ($class >= $CURUSER['class']) stderr($REL_LANG->say_by_key('error'), $REL_LANG->say_by_key('cant_dell_acc'));
	delete_ipb_user($arr["username"]);
	delete_user($id);
	@unlink(ROOT_PATH.$avatar);
	stderr($REL_LANG->say_by_key('success'), "".$REL_LANG->say_by_key('account')." <b>$username</b> ".$REL_LANG->say_by_key('removed')."");
}
stdhead($REL_LANG->say_by_key('delete_account'));
?>
<h1><?=$REL_LANG->say_by_key('delete_account')?></h1>
<table border=1 cellspacing=0 cellpadding=5>
	<form method=post action="<?=$REL_SEO->make_link('delacctadmin')?>">
	<tr>
		<td class=rowhead><?=$REL_LANG->say_by_key('username')?></td>
		<td><input size=40 name=username></td>
	</tr>

	<tr>
		<td colspan=2><input type=submit class=btn
			value='<?=$REL_LANG->say_by_key('remove')?>'></td>
	</tr>
	</form>
</table>
<?
stdfoot();
?>
