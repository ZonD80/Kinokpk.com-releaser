<?php
/**
 * Mass-PM to users
 * @license GNU GPLv3 http://opensource.org/licenses/gpl-3.0.html
 * @package Kinokpk.com releaser
 * @author ZonD80 <admin@kinokpk.com>
 * @copyright (C) 2008-now, ZonD80, Germany, TorrentsBook.com
 * @link http://dev.kinokpk.com
 */


require_once "include/bittorrent.php";
dbconn();
loggedinorreturn();
httpauth();

if (get_user_class() < UC_ADMINISTRATOR)
stderr($REL_LANG->say_by_key('error'), $REL_LANG->say_by_key('access_denied'));

stdhead("����� ���������", false);
?>
<table class=main width=100% border=0 cellspacing=0 cellpadding=0>
	<tr>
		<td class=embedded>
		<div align=center>
		<form method=post name=message action="<?=$REL_SEO->make_link('takestaffmess');?>"><?

		if ($_GET["returnto"] || $_SERVER["HTTP_REFERER"])
		{
			?> <input type=hidden name=returnto
			value=<?=$_GET["returnto"] ? urlencode($_GET["returnto"]) : urlencode($_SERVER["HTTP_REFERER"])?>>
			<?
		}
		?>
		<table cellspacing=0 cellpadding=5>
			<tr>
				<td class="colhead" colspan="2">����� ��������� ���� ������
				������������� � �������������</td>
			</tr>
			<tr>
				<td>���� ����������:<br />
				<table style="border: 0" width="100%" cellpadding="0"
					cellspacing="0">
					<tr>
					<?php
					for ($i=0;;$i++) {
						$class++;
						if ($s = get_user_class_name($i))
						print("<td style=\"border: 0\" width=\"20\"><input type=\"checkbox\" name=\"clases[]\" value=\"$i\"></td><td style=\"border: 0\">$s</td>");
						else
						break;
						if ($class % 4 == 0)
						print("</tr><tr>");
					}
					?>
					</tr>
				</table>
				</td>
			</tr>
			<TD colspan="2">����: <INPUT name="subject" type="text" size="70"></TD>
			</TR>
			<tr>
				<td align="center"><?print textbbcode("msg",$body);?> <!--<textarea name=msg cols=80 rows=15><?=$body?></textarea>-->
				</td>
			</tr>
			<tr>
				<td colspan=2>
				<div align="center"><b>�����������:&nbsp;&nbsp;</b> <?=$CURUSER['username']?>
				<input name="sender" type="radio" value="self" checked> &nbsp;
				������� <input name="sender" type="radio" value="system"></div>
				</td>
			</tr>
			<tr>
				<td colspan=2 align=center><input type=submit value="���������"
					class=btn></td>
			</tr>
		</table>
		<input type=hidden name=receiver value=<?=$receiver?>></form>

		</div>
		</td>
	</tr>
</table>
<?
		stdfoot();
		?>