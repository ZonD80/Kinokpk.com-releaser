<?php
/**
 * Torrent download script
 * @license GNU GPLv3 http://opensource.org/licenses/gpl-3.0.html
 * @package Kinokpk.com releaser
 * @author ZonD80 <admin@kinokpk.com>
 * @copyright (C) 2008-now, ZonD80, Germany, TorrentsBook.com
 * @link http://dev.kinokpk.com
 */

require_once("include/bittorrent.php");
require_once (ROOT_PATH."include/benc.php");

dbconn();
loggedinorreturn();
$REL_LANG->load('download');

$cronrow = sql_query("SELECT * FROM cron WHERE cron_name IN ('rating_enabled','rating_perdownload','rating_downlimit','rating_freetime')");

while ($cronres = mysql_fetch_array($cronrow)) $CRON[$cronres['cron_name']] = $cronres['cron_value'];


if (!is_valid_id($_GET['id'])) 			stderr($REL_LANG->say_by_key('error'), $REL_LANG->say_by_key('invalid_id'));

$readed = isset($_GET['ok']);

$id = (int) $_GET["id"];


$res = sql_query("SELECT torrents.filename, torrents.info_hash, torrents.tiger_hash, torrents.size, torrents.name, torrents.added, torrents.owner AS userid, torrents.freefor, torrents.free, users.username AS owner,torrents.relgroup AS rgid, relgroups.name AS rgname, relgroups.image AS rgimage, IF((torrents.relgroup=0) OR (relgroups.private=0) OR FIND_IN_SET({$CURUSER['id']},relgroups.owners) OR FIND_IN_SET({$CURUSER['id']},relgroups.members),1,(SELECT 1 FROM rg_subscribes WHERE rgid=torrents.relgroup AND userid={$CURUSER['id']})) AS relgroup_allowed FROM torrents LEFT JOIN relgroups ON torrents.relgroup=relgroups.id LEFT JOIN users ON users.id = torrents.owner WHERE torrents.id = ".sqlesc($id)) or sqlerr(__FILE__, __LINE__);
$row = mysql_fetch_array($res);
if (!$row)
stderr($REL_LANG->say_by_key('error'), $REL_LANG->say_by_key('invalid_id'));

if ($row['rgid']) $rgcontent = "<a href=\"relgroups.php?id={$row['rgid']}\">".($row['rgimage']?"<img style=\"border:none;\" title=\"����� ������ {$row['rgname']}\" src=\"{$row['rgimage']}\"/>":'����� ������ '.$row['rgname'])."</a>&nbsp;";

if ((get_user_class()<UC_MODERATOR) && !$row['relgroup_allowed'] && $row['rgid']) stderr($REL_LANG->say_by_key('error'),sprintf($REL_LANG->say_by_key('private_release_access_denied'),$rgcontent));



if ($row["filename"] == 'nofile') stderr ("���������","��� ����� ��� TORRENT �����! ������� ��� � ������ ������� ����������, ���������� ������ � ��������� ������ <a href='details.php?id=".$id."'>� �������� ������</a>");

if ($row['freefor']) {
	$row['freefor']=explode(',',$row['freefor']);
	if (in_array($CURUSER['id'],$row['freefor'])) $userfree=true;
}

$already_downloaded = @mysql_result(sql_query("SELECT 1 FROM snatched WHERE torrent = $id AND userid = {$CURUSER['id']}"),0);

$rating_enabled = (($CRON['rating_enabled'] && ((time()-$CURUSER['added'])>($CRON['rating_freetime']*86400)) && ($id<>$CURUSER['last_downloaded']) && ($row['userid']<>$CURUSER['id']) && (get_user_class() <> UC_VIP) && !$userfree && !$row['free'] && !$already_downloaded)?true:false);


if ($rating_enabled && ($CURUSER['ratingsum']<$CRON['rating_downlimit'])) stderr($REL_LANG->say_by_key('error'),$REL_LANG->say_by_key('rating_low'));

$currating = $CURUSER['ratingsum']-$CRON['rating_perdownload'];
if ($currating>0) $znak='+';
/* @var $hubs Get dchubs to display or not dchubs link form */
$hubs = get_retrackers(false,'dchubs');

if (!$readed) stderr($REL_LANG->say_by_key('downloading_torrent'),($rating_enabled?sprintf($REL_LANG->say_by_key('download_notice'),$CRON['rating_perdownload'],$znak.$currating,$CRON['rating_downlimit']).'<br />':'').'<div align="center"><form action="download.php"><input type="hidden" name="id" value="'.$id.'"><input type="hidden" name="ok" value=""><input type="submit" value="'.$REL_LANG->say_by_key('download_torrent').'">&nbsp;<input type="submit" name="magnet" value="'.$REL_LANG->say_by_key('as_magnet').'">'.(($REL_CONFIG['use_dc']&&$hubs)?'&nbsp;<input type="submit" name="dc_magnet" value="'.$REL_LANG->say_by_key('as_dc_magnet').'">':'').'</form></div>'.(!REL_AJAX?sprintf($REL_LANG->say_by_key('to_details'),$id):''),'success');
if ($_GET['magnet']) $magnet = true; else $magnet=false;
if ($_GET['dc_magnet']) $dc_magnet = true; else $dc_magnet=false;

if (!$dc_magnet && !$magnet && (@ini_get('output_handler') == 'ob_gzhandler') && (@ob_get_length() !== false))
{	// if output_handler = ob_gzhandler, turn it off and remove the header sent by PHP
@ob_end_clean();
header('Content-Encoding:');
}



if (!$magnet && !$dc_magnet) {
	$fn = "torrents/$id.torrent";

	if (!$row || !is_file($fn) || !is_readable($fn))
	stderr($REL_LANG->say_by_key('error'), $REL_LANG->say_by_key('unable_to_read_torrent'));
}

sql_query("UPDATE torrents SET hits = hits + 1 WHERE id = ".sqlesc($id));
if ($rating_enabled) sql_query("UPDATE users SET ratingsum = ratingsum-{$CRON['rating_perdownload']}, last_downloaded=$id WHERE id={$CURUSER['id']}");

if ($dc_magnet) {
	if (!$row['tiger_hash']) stderr($REL_LANG->say_by_key('error'),$REL_LANG->say_by_key('no_tiger'));
	// look upstairs
	if (!$hubs) stderr($REL_LANG->say_by_key('error'),sprintf($REL_LANG->say_by_key('no_dchubs'),$id,$id));
	$link = make_dc_magnet($row['tiger_hash'],$row['name'],$row['size'],$hubs);
	$message = $REL_LANG->say_by_key('this_is_dc_magnet').'<h1><a href="'.$link.'">'.$REL_LANG->say_by_key('magnet').'</a></h1>'.(!REL_AJAX?sprintf($REL_LANG->say_by_key('to_details'),$id):'');
	stderr($REL_LANG->say_by_key('this_is_magnet_title'),$message,'success');
}

if (strlen($CURUSER['passkey']) != 32) {
	$CURUSER['passkey'] = md5($CURUSER['username'].time().$CURUSER['passhash']);
	sql_query("UPDATE users SET passkey=".sqlesc($CURUSER[passkey])." WHERE id=".sqlesc($CURUSER[id]));
}

$announce_urls_list[] = $REL_CONFIG['defaultbaseurl']."/announce.php?passkey=".$CURUSER['passkey'];
$announce_sql = sql_query("SELECT tracker FROM trackers WHERE torrent=$id AND tracker<>'localhost'");
while (list($announce) = mysql_fetch_array($announce_sql)) $announce_urls_list[] = $announce;

$retrackers = get_retrackers();
//var_dump($retrackers);
if ($retrackers) foreach ($retrackers as $announce)
if (!in_array($announce,$announce_urls_list)) $announce_urls_list[] = $announce;

if ($magnet) {
	$link = make_magnet($row['info_hash'],$row['name'],$announce_urls_list);
	$message = $REL_LANG->say_by_key('this_is_magnet').'<h1><a href="'.$link.'">'.$REL_LANG->say_by_key('magnet').'</a></h1>'.(!REL_AJAX?sprintf($REL_LANG->say_by_key('to_details'),$id):'');
	stderr($REL_LANG->say_by_key('this_is_magnet_title'),$message,'success');
}
put_announce_urls($dict,$announce_urls_list);

$dict['type'] = 'dictionary';

$dict['value']['info'] = bdec_file($fn, (1024*1024));


$dict['value']['comment']=bdec(benc_str( "{$REL_CONFIG['defaultbaseurl']}/details.php?id=$id")); // change torrent comment  to URL
$dict['value']['created by']=bdec(benc_str( $row['owner'])); // change created by
$dict['value']['creation date']=bdec(benc_int($row['added'])); // change created on
$dict['value']['publisher']=bdec(benc_str( $row['owner'])); // change publisher
$dict['value']['publisher.utf-8']=bdec(benc_str( $row['owner'])); // change publisher.utf-8
$dict['value']['publisher-url']=bdec(benc_str( "{$REL_CONFIG['defaultbaseurl']}/userdetails.php?id={$row['userid']}")); // change publisher-url
$dict['value']['publisher-url.utf-8']=bdec(benc_str( "{$REL_CONFIG['defaultbaseurl']}/userdetails.php?id={$row['userid']}")); // change publisher-url.utf-8

//print('BENCODED: <hr />'.(($row['info_blob'])));
//die($row['info_blob']);
header ("Expires: Tue, 1 Jan 1980 00:00:00 GMT");
header ("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header ("Cache-Control: no-store, no-cache, must-revalidate");
header ("Cache-Control: post-check=0, pre-check=0", false);
header ("Pragma: no-cache");
header ("X-Powered-by: Kinokpk.com releaser - http://www.kinokpk.com - http://dev.kinokpk.com");
header ("Accept-Ranges: bytes");
header ("Connection: close");
header ("Content-Transfer-Encoding: binary");
header ("Content-Disposition: attachment; filename=\"{$_SERVER['HTTP_HOST']}-$id-".translit($row['name']).".torrent\"");
header ("Content-Type: application/x-bittorrent");
ob_implicit_flush(true);


print(benc($dict));

?>